import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const FrontoraApp());

const ink = Color(0xFF18233A);
const violet = Color(0xFF635BFF);
const pale = Color(0xFFF4F5FA);

class FrontoraApp extends StatelessWidget {
  const FrontoraApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Frontora 2.0',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      useMaterial3: true,
      scaffoldBackgroundColor: pale,
      colorScheme: ColorScheme.fromSeed(seedColor: violet, brightness: Brightness.light),
      appBarTheme: const AppBarTheme(backgroundColor: pale, foregroundColor: ink, elevation: 0),
      inputDecorationTheme: InputDecorationTheme(
        filled: true, fillColor: Colors.white,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: Color(0xFFE7E9F1))),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: violet, width: 1.5)),
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      ),
    ),
    home: const HomePage(),
  );
}

class DocData {
  final Map<String, TextEditingController> c = {};
  final Map<String, String> choices = {
    'docType': 'Lab Report',
    'department': 'Department of Computer Science and Engineering',
    'designation': 'Lecturer',
    'semester': 'Spring',
    'quality': 'High',
  };
  Uint8List? logoBytes;

  static const fields = <String, String>{
    'university': 'Institution Name',
    'docTitle': 'Document Title',
    'courseCode': 'Course Code',
    'reportNo': 'Lab Report No.',
    'courseTitle': 'Course Title',
    'experiment': 'Experiment Name',
    'experimentDate': 'Date of Experiment',
    'submissionDate': 'Date of Submission',
    'teacher': "Teacher's Name",
    'designationOther': 'Custom Designation',
    'student': "Student's Name",
    'studentId': "Student's ID",
    'batch': 'Batch',
    'year': 'Year',
    'departmentOther': 'Custom Department',
    'docTypeOther': 'Custom Document Type',
  };

  DocData() {
    for (final key in fields.keys) { c[key] = TextEditingController(); }
  }
  String val(String key) => c[key]?.text.trim() ?? '';
  String get type => choices['docType'] == 'Other' ? (val('docTypeOther').isEmpty ? 'Document' : val('docTypeOther')) : choices['docType']!;
  String get department => choices['department'] == 'Other' ? val('departmentOther') : choices['department']!;
  String get designation => choices['designation'] == 'Other' ? val('designationOther') : choices['designation']!;
  String get reportLabel => type == 'Lab Report' ? 'Lab Report No.' : '$type No.';
  Map<String, dynamic> toJson() => {
    'fields': {for (final e in c.entries) e.key: e.value.text},
    'choices': choices,
  };
  void load(Map<String, dynamic> j) {
    final fs = (j['fields'] as Map?) ?? {};
    for (final e in fs.entries) { if (c.containsKey(e.key)) c[e.key]!.text = '${e.value ?? ''}'; }
    final cs = (j['choices'] as Map?) ?? {};
    for (final e in cs.entries) { if (choices.containsKey(e.key)) choices[e.key] = '${e.value}'; }
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override State<HomePage> createState() => _HomePageState();
}
class _HomePageState extends State<HomePage> {
  final data = DocData();
  bool loading = true;
  @override void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString('frontora_form');
    if (raw != null) { try { data.load(jsonDecode(raw)); } catch (_) {} }
    if (mounted) setState(() => loading = false);
  }
  Future<void> _save() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('frontora_form', jsonEncode(data.toJson()));
  }
  @override Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(children: [Container(width: 34, height: 34, decoration: BoxDecoration(color: violet, borderRadius: BorderRadius.circular(11)), child: const Icon(Icons.description_rounded, color: Colors.white, size: 20)), const SizedBox(width: 10), const Text('Frontora', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: -.5)), const SizedBox(width: 6), const Text('2.0', style: TextStyle(color: violet, fontWeight: FontWeight.w700, fontSize: 13))]),
        actions: [IconButton(onPressed: _save, icon: const Icon(Icons.save_outlined), tooltip: 'Save draft')],
      ),
      body: loading ? const Center(child: CircularProgressIndicator()) : SafeArea(child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 28),
        children: [
          Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF262F52), Color(0xFF625BFF)], begin: Alignment.topLeft, end: Alignment.bottomRight), borderRadius: BorderRadius.circular(24)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('ACADEMIC DOCUMENT STUDIO', style: TextStyle(color: Color(0xFFDAD8FF), fontSize: 10, fontWeight: FontWeight.w800, letterSpacing: 1.4)),
              const SizedBox(height: 12),
              const Text('Create a cover page\nthat looks professional.', style: TextStyle(color: Colors.white, fontSize: 25, height: 1.16, fontWeight: FontWeight.w800)),
              const SizedBox(height: 12),
              const Text('Build, preview and export your academic documents — all on your device.', style: TextStyle(color: Color(0xFFE3E5FF), height: 1.45)),
              const SizedBox(height: 20),
              FilledButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => EditorPage(data: data, onSave: _save))), icon: const Icon(Icons.add), label: const Text('Create document'), style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: ink, padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14))),
            ]),
          ),
          const SizedBox(height: 24),
          const Text('Your workspace', style: TextStyle(color: ink, fontWeight: FontWeight.w800, fontSize: 18)),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: _featureCard(Icons.edit_note_rounded, 'Smart editor', 'All cover fields')),
            const SizedBox(width: 10),
            Expanded(child: _featureCard(Icons.visibility_outlined, 'Live preview', 'A4 layout')),
          ]),
          const SizedBox(height: 10),
          Row(children: [
            Expanded(child: _featureCard(Icons.picture_as_pdf_outlined, 'PDF export', 'Print-ready')),
            const SizedBox(width: 10),
            Expanded(child: _featureCard(Icons.image_outlined, 'PNG export', 'High resolution')),
          ]),
          const SizedBox(height: 22),
          Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)), child: const Row(children: [Icon(Icons.phone_android_rounded, color: violet), SizedBox(width: 12), Expanded(child: Text('Private by design. Your draft is stored locally on this device.', style: TextStyle(color: ink, fontSize: 13, height: 1.4)))])),
        ],
      )),
    );
  }
  Widget _featureCard(IconData icon, String title, String sub) => Container(padding: const EdgeInsets.all(15), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(17)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(icon, color: violet, size: 22), const SizedBox(height: 10), Text(title, style: const TextStyle(fontWeight: FontWeight.w700, color: ink)), const SizedBox(height: 3), Text(sub, style: const TextStyle(color: Colors.black54, fontSize: 12))]));
}

class EditorPage extends StatefulWidget {
  final DocData data; final Future<void> Function() onSave;
  const EditorPage({super.key, required this.data, required this.onSave});
  @override State<EditorPage> createState() => _EditorPageState();
}
class _EditorPageState extends State<EditorPage> {
  final GlobalKey previewKey = GlobalKey();
  bool exporting = false;
  DocData get d => widget.data;
  @override void initState() { super.initState(); for (final c in d.c.values) { c.addListener(_changed); } }
  @override void dispose() { for (final c in d.c.values) { c.removeListener(_changed); } super.dispose(); }
  void _changed() { if (mounted) setState(() {}); }
  Future<void> _pickLogo() async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 92);
    if (x != null) { d.logoBytes = await x.readAsBytes(); setState(() {}); }
  }
  Future<Uint8List?> _capture() async {
    await WidgetsBinding.instance.endOfFrame;
    final boundary = previewKey.currentContext?.findRenderObject() as RenderRepaintBoundary?;
    if (boundary == null) return null;
    final image = await boundary.toImage(pixelRatio: _pixelRatio);
    final bytes = await image.toByteData(format: ui.ImageByteFormat.png);
    image.dispose();
    return bytes?.buffer.asUint8List();
  }
  double get _pixelRatio => switch (d.choices['quality']) {'Low' => 1.5, 'Medium' => 2.5, 'High' => 3.5, _ => 4.5};
  Future<void> _exportPng() async {
    setState(() => exporting = true);
    try {
      final bytes = await _capture();
      if (bytes == null) throw Exception('Preview could not be captured.');
      final dir = await getTemporaryDirectory();
      final file = File('${dir.path}/Frontora_Cover.png');
      await file.writeAsBytes(bytes, flush: true);
      await SharePlus.instance.share(ShareParams(files: [XFile(file.path)], text: 'Created with Frontora 2.0'));
    } catch (e) { _message('PNG export failed: $e'); }
    if (mounted) setState(() => exporting = false);
  }
  Future<void> _exportPdf() async {
    setState(() => exporting = true);
    try {
      final pdf = pw.Document();
      final logo = d.logoBytes;
      pdf.addPage(pw.Page(pageFormat: PdfPageFormat.a4, margin: const pw.EdgeInsets.all(0), build: (_) {
        pw.Widget line(String label, String value) => pw.Padding(padding: const pw.EdgeInsets.only(bottom: 13), child: pw.Row(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [pw.SizedBox(width: 145, child: pw.Text(label, style: pw.TextStyle(fontSize: 11, color: PdfColors.grey700))), pw.Expanded(child: pw.Text(value.isEmpty ? '—' : value, style: pw.TextStyle(fontSize: 11, fontWeight: pw.FontWeight.bold, color: PdfColors.blueGrey900)))]));
        return pw.Container(padding: const pw.EdgeInsets.fromLTRB(48, 34, 48, 34), decoration: pw.BoxDecoration(border: pw.Border.all(color: PdfColors.grey300, width: 1)), child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.stretch, children: [
          pw.Container(height: 7, color: PdfColor.fromHex('#635BFF')),
          pw.SizedBox(height: 28),
          if (logo != null) pw.Center(child: pw.Image(pw.MemoryImage(logo), height: 74, fit: pw.BoxFit.contain)),
          pw.SizedBox(height: 18),
          pw.Center(child: pw.Text(d.val('university').isEmpty ? 'INSTITUTION NAME' : d.val('university').toUpperCase(), textAlign: pw.TextAlign.center, style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold, color: PdfColor.fromHex('#18233A')))),
          pw.SizedBox(height: 9),
          pw.Center(child: pw.Text(d.department, textAlign: pw.TextAlign.center, style: const pw.TextStyle(fontSize: 11))),
          pw.SizedBox(height: 32),
          pw.Center(child: pw.Text(d.type.toUpperCase(), style: pw.TextStyle(fontSize: 17, fontWeight: pw.FontWeight.bold, color: PdfColor.fromHex('#635BFF')))),
          pw.SizedBox(height: 22),
          pw.Center(child: pw.Text(d.val('docTitle').isEmpty ? 'DOCUMENT TITLE' : d.val('docTitle'), textAlign: pw.TextAlign.center, style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold))),
          pw.SizedBox(height: 26),
          line('Course Code', d.val('courseCode')), line('Course Title', d.val('courseTitle')),
          line(d.reportLabel, d.val('reportNo')), line('Experiment Name', d.val('experiment')),
          line('Date of Experiment', d.val('experimentDate')), line('Date of Submission', d.val('submissionDate')),
          pw.Spacer(),
          pw.Row(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
            pw.Expanded(child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [pw.Text('Submitted To', style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 12)), pw.SizedBox(height: 8), pw.Text(d.val('teacher')), pw.Text(d.designation)])),
            pw.SizedBox(width: 20),
            pw.Expanded(child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [pw.Text('Submitted By', style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 12)), pw.SizedBox(height: 8), pw.Text(d.val('student')), pw.Text('ID: ${d.val('studentId')}'), pw.Text('Batch: ${d.val('batch')}'), pw.Text('${d.choices['semester']} ${d.val('year')}')])),
          ]),
          pw.SizedBox(height: 26),
          pw.Center(child: pw.Text('Frontora 2.0', style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey500))),
        ]));
      }));
      final bytes = await pdf.save();
      await Printing.sharePdf(bytes: bytes, filename: 'Frontora_Cover.pdf');
    } catch (e) { _message('PDF export failed: $e'); }
    if (mounted) setState(() => exporting = false);
  }
  void _message(String s) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s)));
  Widget _section(String title, String subtitle, List<Widget> children) => Container(margin: const EdgeInsets.only(bottom: 14), padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: ink)), const SizedBox(height: 3), Text(subtitle, style: const TextStyle(fontSize: 11, color: Colors.black45)), const SizedBox(height: 14), ...children]));
  Widget _field(String key, {String? label, String? hint, TextInputType? type}) => Padding(padding: const EdgeInsets.only(bottom: 11), child: TextField(controller: d.c[key], keyboardType: type, decoration: InputDecoration(labelText: label ?? DocData.fields[key], hintText: hint)));
  Widget _select(String key, String label, List<String> options) => Padding(padding: const EdgeInsets.only(bottom: 11), child: DropdownButtonFormField<String>(value: d.choices[key], isExpanded: true, decoration: InputDecoration(labelText: label), items: options.map((e) => DropdownMenuItem(value: e, child: Text(e, overflow: TextOverflow.ellipsis))).toList(), onChanged: (v) { if (v != null) setState(() => d.choices[key] = v); }));
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Document editor', style: TextStyle(fontWeight: FontWeight.w800)), actions: [IconButton(onPressed: () async { await widget.onSave(); _message('Draft saved on this device.'); }, icon: const Icon(Icons.save_outlined))]),
    body: ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 24), children: [
      _section('Document setup', 'Choose the type and add institution details.', [
        _select('docType', 'Document Type', ['Lab Report', 'Quiz Test', 'Assignment', 'Other']),
        if (d.choices['docType'] == 'Other') _field('docTypeOther'),
        _field('university'),
        Row(children: [Expanded(child: Text(d.logoBytes == null ? 'Institution logo (optional)' : 'Logo selected', style: const TextStyle(fontWeight: FontWeight.w600))), TextButton.icon(onPressed: _pickLogo, icon: const Icon(Icons.upload_outlined), label: const Text('Upload'))]),
        if (d.logoBytes != null) Row(children: [Image.memory(d.logoBytes!, height: 48, width: 48, fit: BoxFit.contain), TextButton(onPressed: () => setState(() => d.logoBytes = null), child: const Text('Remove'))]),
        _select('department', 'Department', ['Department of Bangla','Department of Business Administration','Department of Civil Engineering','Department of Computer Science and Engineering','Department of Education','Department of Electrical and Electronic Engineering','Department of English','Department of Fashion Design and Technology','Department of Islamic Studies','Department of Law','Department of Mathematics','Department of Physics','Department of Physical Education','Department of Textile Engineering','Other']),
        if (d.choices['department'] == 'Other') _field('departmentOther'),
        _field('docTitle'),
      ]),
      _section('Course information', 'Add course and assignment information.', [
        _field('courseCode', hint: 'e.g. CSE1202'), _field('courseTitle'),
        _field('reportNo', label: d.reportLabel, hint: 'e.g. 01'), _field('experiment', label: d.type == 'Lab Report' ? 'Experiment Name' : 'Topic / Subject Name'),
        _field('experimentDate', label: 'Date of Experiment (YYYY-MM-DD)', hint: 'YYYY-MM-DD'),
        _field('submissionDate', label: 'Date of Submission (YYYY-MM-DD)', hint: 'YYYY-MM-DD'),
      ]),
      _section('Submitted to', 'Teacher and designation.', [
        _field('teacher'),
        _select('designation', 'Designation', ['Lecturer','Assistant Professor','Associate Professor','Professor','Head of the Department','Other']),
        if (d.choices['designation'] == 'Other') _field('designationOther'),
      ]),
      _section('Submitted by', 'Student details.', [
        _field('student'), _field('studentId'), _field('batch', hint: 'e.g. 49 (G)'),
        _select('semester', 'Semester', ['Spring','Summer','Fall']),
        _field('year', label: 'Year', hint: 'e.g. 2026', type: TextInputType.number),
      ]),
      _section('Live preview & export', 'Your A4 cover updates as you type.', [
        _select('quality', 'PNG quality', ['Low','Medium','High','Ultra']),
        RepaintBoundary(key: previewKey, child: _CoverPreview(d: d)),
        const SizedBox(height: 14),
        Row(children: [
          Expanded(child: OutlinedButton.icon(onPressed: exporting ? null : _exportPng, icon: const Icon(Icons.image_outlined), label: const Text('PNG'))),
          const SizedBox(width: 10),
          Expanded(child: FilledButton.icon(onPressed: exporting ? null : _exportPdf, icon: const Icon(Icons.picture_as_pdf_outlined), label: Text(exporting ? 'Preparing…' : 'Export PDF'))),
        ]),
      ]),
    ]),
  );
}

class _CoverPreview extends StatelessWidget {
  final DocData d;
  const _CoverPreview({required this.d});
  String v(String key, [String fallback = '']) => d.val(key).isEmpty ? fallback : d.val(key);
  @override Widget build(BuildContext context) => AspectRatio(aspectRatio: 210 / 297, child: Container(
    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
    decoration: BoxDecoration(color: Colors.white, border: Border.all(color: const Color(0xFFE1E3EA)), boxShadow: [BoxShadow(color: Colors.black.withOpacity(.06), blurRadius: 14, offset: const Offset(0, 5))]),
    child: Column(children: [
      Container(height: 5, color: violet), const SizedBox(height: 16),
      if (d.logoBytes != null) Image.memory(d.logoBytes!, height: 46, fit: BoxFit.contain),
      Text(v('university', 'INSTITUTION NAME').toUpperCase(), textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 12, color: ink)),
      const SizedBox(height: 4),
      Text(d.department.isEmpty ? 'Department' : d.department, textAlign: TextAlign.center, style: const TextStyle(fontSize: 7.5, color: Colors.black54)),
      const SizedBox(height: 20),
      Text(d.type.toUpperCase(), style: const TextStyle(fontSize: 11, color: violet, fontWeight: FontWeight.w900, letterSpacing: 1)),
      const SizedBox(height: 12),
      Text(v('docTitle', 'DOCUMENT TITLE'), textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: ink)),
      const SizedBox(height: 16),
      _previewLine('Course Code', v('courseCode', '—')),
      _previewLine('Course Title', v('courseTitle', '—')),
      _previewLine(d.reportLabel, v('reportNo', '—')),
      _previewLine(d.type == 'Lab Report' ? 'Experiment Name' : 'Topic / Subject', v('experiment', '—')),
      _previewLine('Date of Experiment', v('experimentDate', '—')),
      _previewLine('Date of Submission', v('submissionDate', '—')),
      const Spacer(),
      Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('Submitted To', style: TextStyle(fontSize: 8, fontWeight: FontWeight.w900)), const SizedBox(height: 5), Text(v('teacher', 'Teacher name'), style: const TextStyle(fontSize: 7.5)), Text(d.designation, style: const TextStyle(fontSize: 7))])),
        const SizedBox(width: 8),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('Submitted By', style: TextStyle(fontSize: 8, fontWeight: FontWeight.w900)), const SizedBox(height: 5), Text(v('student', 'Student name'), style: const TextStyle(fontSize: 7.5)), Text('ID: ${v('studentId', '—')}', style: const TextStyle(fontSize: 7)), Text('Batch: ${v('batch', '—')}', style: const TextStyle(fontSize: 7)), Text('${d.choices['semester']} ${v('year', '')}', style: const TextStyle(fontSize: 7))])),
      ]),
      const SizedBox(height: 14),
      const Text('FRONTORA 2.0', style: TextStyle(fontSize: 6, color: Colors.black38, letterSpacing: 1.5)),
    ]),
  ));
  Widget _previewLine(String label, String value) => Padding(padding: const EdgeInsets.only(bottom: 8), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [SizedBox(width: 90, child: Text(label, style: const TextStyle(fontSize: 7, color: Colors.black54))), Expanded(child: Text(value, style: const TextStyle(fontSize: 7.5, fontWeight: FontWeight.w700, color: ink)))]));
}
