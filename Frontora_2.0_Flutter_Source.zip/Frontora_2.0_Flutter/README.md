# Frontora 2.0 — Native Flutter Android source

This is a fresh Flutter/Dart implementation, not an HTML wrapper or WebView.

## Included in this first build
- Modern Material 3 Android interface
- Document types: Lab Report, Quiz Test, Assignment, Other/custom
- Institution name and optional logo upload/remove
- All departments from the supplied HTML, including custom department
- Document title, course code/title, report number, experiment/topic, dates
- Teacher name and designation, including custom designation
- Student name, ID, batch, semester, year
- Live A4-style preview
- PDF export/share and PNG export/share
- Local draft persistence with SharedPreferences

## Requirements
- Flutter SDK (Dart 3.3+)
- Android Studio / Android SDK
- Android device or emulator

## Run
```bash
flutter create . --platforms=android
flutter pub get
flutter run
```

## Build APK
```bash
flutter build apk --release
```
APK output: `build/app/outputs/flutter-apk/app-release.apk`

## Notes
- This source has not been compiled or device-tested in this environment.
- `pubspec.yaml` uses `any` for package constraints so Pub can resolve compatible current releases; before a production release, pin and test exact versions.
- PDF is generated with Flutter's PDF library. PNG is captured from the native Flutter preview widget. No HTML, JavaScript, html2canvas, or WebView is used.
- Draft form fields are stored locally. The optional logo remains in memory for the current editing session in this initial scaffold; persistent logo storage is a follow-up improvement.
